Group Members:

Kai Laxdal
16kibl
16kibl@queensu.ca
20063565

Brent Littlefield
16bml1
16bml1@queensu.ca
20060929
